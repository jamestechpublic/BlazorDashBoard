﻿namespace BlazorDashboard02.Shared.DTO
{
    public class DashboardCardDTO
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
    }
}
