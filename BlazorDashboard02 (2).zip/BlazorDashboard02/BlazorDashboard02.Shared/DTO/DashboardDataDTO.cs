﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlazorDashboard02.Shared.DTO
{
    public class DashboardDataDTO
    {
        public List<double> PlayerA { get; set; } = new List<double>();
        public List<double> PlayerB { get; set; } = new List<double>();
    }
}
