﻿namespace BlazorDashboard02.Shared.DTO
{
    public class DashboardUserDTO
    {
        public int UserId { get; set; }
        public int CardId { get; set; }
    }
}
