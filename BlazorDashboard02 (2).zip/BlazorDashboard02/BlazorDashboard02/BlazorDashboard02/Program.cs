using BlazorDashboard02.Components;
using BlazorDashboard02.Hubs;
using MudBlazor.Services;

namespace BlazorDashboard02
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddRazorComponents()
                .AddInteractiveServerComponents()
                .AddInteractiveWebAssemblyComponents();

            builder.Services.AddMudServices();

            builder.Services.AddHostedService<DashboardUpdateService>();


            var apiUrl = builder.Configuration["DashboardApiUrl"] ?? "https://localhost:7142";
            builder.Services.AddHttpClient("DashboardAPI", client =>
            {
                client.BaseAddress = new Uri(apiUrl);
            });
            builder.Services.AddScoped(sp =>
                sp.GetRequiredService<IHttpClientFactory>().CreateClient("DashboardAPI"));

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseWebAssemblyDebugging();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();

            app.UseAntiforgery();

            app.MapStaticAssets();
            app.MapRazorComponents<App>()
                .AddInteractiveServerRenderMode()
                .AddInteractiveWebAssemblyRenderMode()
                .AddAdditionalAssemblies(typeof(Client._Imports).Assembly);

            app.MapHub<DashboardHub>("/dashboardhub");

            app.Run();
        }
    }
}
