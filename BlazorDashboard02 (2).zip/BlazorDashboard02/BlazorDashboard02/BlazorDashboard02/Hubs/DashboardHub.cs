﻿using BlazorDashboard02.Shared.DTO;
using Microsoft.AspNetCore.SignalR;

namespace BlazorDashboard02.Hubs
{
    public class DashboardHub : Hub
    {
        public async Task SendUpdate(DashboardDataDTO data)
        {
            await Clients.All.SendAsync("ReceiveDashboardUpdate", data);
        }

    }
}
