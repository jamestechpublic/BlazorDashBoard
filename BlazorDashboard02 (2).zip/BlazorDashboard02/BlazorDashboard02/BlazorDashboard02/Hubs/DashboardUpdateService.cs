﻿using BlazorDashboard02.Shared.DTO;
using Microsoft.AspNetCore.SignalR;

namespace BlazorDashboard02.Hubs
{
    public class DashboardUpdateService : BackgroundService
    {
        private readonly IHubContext<DashboardHub> _hubContext;

        public DashboardUpdateService(IHubContext<DashboardHub> hubContext)
        {
            _hubContext = hubContext;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                var data = new DashboardDataDTO
                {
                    PlayerA = new List<double> { GetRandomValue(), GetRandomValue(), GetRandomValue(), 
                                                 GetRandomValue(), GetRandomValue(), GetRandomValue() },
                    PlayerB = new List<double> { GetRandomValue(), GetRandomValue(), GetRandomValue(),
                                                 GetRandomValue(), GetRandomValue(), GetRandomValue() },
                };

                await _hubContext.Clients.All.SendAsync("ReceiveDashboardUpdate", data);

                await Task.Delay(TimeSpan.FromSeconds(3), stoppingToken);
            }
        }

        private double GetRandomValue()
        {
            var random = new Random();
            return random.NextDouble() * 100;
        }

    }
}
