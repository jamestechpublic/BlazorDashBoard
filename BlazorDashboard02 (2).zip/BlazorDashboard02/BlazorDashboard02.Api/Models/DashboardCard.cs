﻿namespace BlazorDashboard02.Api.Models
{
    public class DashboardCard
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
    }
}
