﻿namespace BlazorDashboard02.Api.Models
{
    public class DashboardUser
    {
        public int UserId { get; set; }
        public int CardId { get; set; }
    }
}
