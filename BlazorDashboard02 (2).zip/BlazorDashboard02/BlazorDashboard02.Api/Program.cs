using BlazorDashboard02.Api.Services;

namespace BlazorDashboard02.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
            builder.Services.AddOpenApi();

            builder.Services.AddScoped<IDashboardService, DashboardService>();

            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowBlazorClient",
                    policy => policy.WithOrigins("https://localhost:7072") // WASM app origin
                                    .AllowAnyHeader()
                                    .AllowAnyMethod());
            });
            
            var app = builder.Build();
            
            app.UseCors("AllowBlazorClient");


            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.MapOpenApi();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
