﻿using BlazorDashboard02.Api.Models;
using BlazorDashboard02.Shared.DTO;

namespace BlazorDashboard02.Api.Services
{
    public class DashboardService : IDashboardService
    {
        readonly List<DashboardCard> _cards = new List<DashboardCard>
        {
            new DashboardCard { Id = 1, Title = "Card 1", Content = "CardComp1" },
            new DashboardCard { Id = 2, Title = "Card 2", Content = "CardComp2" },
            new DashboardCard { Id = 3, Title = "Card 3", Content = "CardComp3" }
        };

        List<DashboardUser> _cardUsers = new List<DashboardUser>
        {
            new DashboardUser { UserId = 1, CardId = 1 },
            new DashboardUser { UserId = 1, CardId = 3 }
        };

        public async Task<List<DashboardCardDTO>> GetCardsForUserAsync(int userId)
        {
            var cards = from c in _cards
                        join cu in _cardUsers on c.Id equals cu.CardId
                        where cu.UserId == userId
                        select ConvertToDTO(c);

            return await Task.FromResult(cards.ToList());
        }

        public async Task UpdateUserDashboardAsync(int userId, List<int> cardIds)
        {
            _cardUsers.RemoveAll(cu => cu.UserId == userId);

            foreach (var cardId in cardIds)
            {
                _cardUsers.Add(new DashboardUser { UserId = userId, CardId = cardId });
            }
            await Task.CompletedTask;
        }

        public async Task<List<DashboardCardDTO>> GetAllCardsAsync()
        {
            var result = _cards.Select(c => ConvertToDTO(c));

            return await Task.FromResult(result.ToList());
        }

        DashboardCardDTO ConvertToDTO(DashboardCard card)
        {
            return new DashboardCardDTO { Id = card.Id, Title = card.Title, Content = card.Content };
        }
    }
}
