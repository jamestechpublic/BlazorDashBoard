﻿using BlazorDashboard02.Shared.DTO;

namespace BlazorDashboard02.Api.Services
{
    public interface IDashboardService
    {
        Task<List<DashboardCardDTO>> GetAllCardsAsync();
        Task<List<DashboardCardDTO>> GetCardsForUserAsync(int userId);
        Task UpdateUserDashboardAsync(int userId, List<int> cardIds);
    }
}
