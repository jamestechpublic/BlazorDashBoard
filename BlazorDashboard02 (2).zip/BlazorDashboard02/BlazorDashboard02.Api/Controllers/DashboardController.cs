﻿using BlazorDashboard02.Api.Services;
using BlazorDashboard02.Shared.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using static System.Net.WebRequestMethods;

namespace BlazorDashboard02.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DashboardController(IDashboardService _service) : ControllerBase
    {
        [HttpGet("GetAllCards")]
        public async Task<IActionResult> GetAllCards()
        {
            var result = await _service.GetAllCardsAsync();

            return Ok(result);
        }

        [HttpGet("GetCardsForUser/{userId}")]
        public async Task<IActionResult> GetCardsForUserAsync(int userId)
        {
            var result = await _service.GetCardsForUserAsync(userId);
            return Ok(result);
        }

        [HttpPost("UpdateUserDashboard/{userId}")]
        public async Task<IActionResult> UpdateUserDashboardAsync(int userId, [FromBody] List<int> cardIds)
        {
            await _service.UpdateUserDashboardAsync(userId, cardIds);
            return Ok();
        }
    }
}
